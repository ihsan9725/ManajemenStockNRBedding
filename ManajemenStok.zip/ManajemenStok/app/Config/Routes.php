<?php


// use App\Controllers\Pages;
// use App\Controllers\CategoriesController;

use App\Controllers\Pages;
use App\Controllers\SellerController;
use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 */
$routes->setDefaultNamespace('App\Controllers');
// $routes->setDefaultController('Pages');
$routes->setDefaultMethod('index');
$routes->setTranslateURIDashes(false);
// $routes->set404Override();
$routes->setAutoRoute(true);
$routes->setDefaultController('AuthController');



//auth
$routes->group('auth', function ($routes) {
    $routes->post('/', 'AuthController::index');
    $routes->get('register', 'AuthController::register');
    $routes->post('registerProcess', 'AuthController::registerProcess');
    $routes->get('login', 'AuthController::login');
    $routes->post('loginProcess', 'AuthController::loginProcess');
    $routes->get('logout', 'AuthController::logout');
});

//stock
$routes->group('pages', ['filter' => 'auth'], function ($routes) {
    // $routes->get('/', 'Pages::index');
    $routes->get('home', 'Pages::home');
    $routes->get('profile', 'Pages::profile');
    $routes->get('stock', 'Pages::stock');
    $routes->get('edit(:num)', 'Pages::edit/$1');
    $routes->post('update/(:num)', 'Pages::update/$1');
    $routes->post('save', 'Pages::save');
    $routes->get('delete/(:num)', 'Pages::delete/$1');
    $routes->get('categories', 'CategoriesController::categories'); //jika ingin ambil data dari stock ke kategori
    $routes->get('getStockData/(:num)', 'Pages::getStockData/$1'); //untuk data form otomatis barang;;harga

});
// Categories
$routes->group('categories', function ($routes) {
    // $routes->get('/', 'CategoriesController::index');
    $routes->get('categories', 'CategoriesController::categories');
    $routes->post('save', 'CategoriesController::save');
    $routes->get('edit(:num)', 'CategoriesController::edit/$1');
    $routes->post('update/(:num)', 'CategoriesController::update/$1');
    $routes->get('delete/(:num)', 'CategoriesController::delete/$1');
    $routes->get('stock', 'Pages::stock'); //jika ingin ambil data dari stock ke kategori
});
// seller
$routes->group('seller', function ($routes) {
    // $routes->get('/', 'SellerController::index');
    $routes->get('seller', 'SellerController::seller');
    $routes->post('save', 'SellerController::save');
    $routes->get('edit(:num)', 'SellerController::edit/$1');
    $routes->post('update/(:num)', 'SellerController::update/$1');
    $routes->get('delete/(:num)', 'SellerController::delete/$1');
    $routes->get('getStockData/(:num)', 'SellerController::getStockData/$1'); //untuk data form otomatis barang;;harga
    $routes->get('excel', 'SellerController::excel');
    $routes->get('invoice/(:num)', 'SellerController::generatePDF/$1');
});
// supplier
$routes->group('supplier', function ($routes) {
    // $routes->get('/', 'SupplierController::index');
    $routes->get('supplier', 'SupplierController::supplier');
    $routes->post('save', 'SupplierController::save');
    $routes->get('edit(:num)', 'SupplierController::edit/$1');
    $routes->post('update/(:num)', 'SupplierController::update/$1');
    $routes->get('delete/(:num)', 'SupplierController::delete/$1');
});
// export
$routes->group('export', function ($routes) {
    // $routes->get('/', 'SupplierController::index');
    $routes->get('exportCSV', 'ExportController::exportCSV');
});
