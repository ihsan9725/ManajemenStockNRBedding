<?php

namespace App\Models;

use CodeIgniter\Commands\Utilities\Publish;
use CodeIgniter\Model;

class CategoriesModel extends Model
{
    protected $table = 'kategori_barang';
    protected $primaryKey = 'id_kategori';
    protected $allowedFields = ['id_ktgri', 'nama_kategori', 'spesifikasi'];

    protected $useTimestamps = true;

    public function getCategories()
    {
        return $this->findAll();
    }
}
