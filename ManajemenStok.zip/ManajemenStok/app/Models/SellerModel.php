<?php

namespace App\Models;

use CodeIgniter\Model;

class SellerModel extends Model
{
    protected $table = 'penjualan';
    protected $primaryKey = 'id';
    protected $allowedFields = ['no_transaksi', 'nama_pelanggan', 'nama_barang', 'jml_terjual', 'total_harga', 'harga_beli', 'harga_satuan_toko', 'total_biaya_beli', 'keuntungan', 'metode_pembayaran', 'keterangan'];
    protected $useTimestamps = true;

    // for get stock data
    public function getTotalSales()
    {
        return $this->countAllResults();
    }
}
class StockModel1 extends Model
{
    protected $table = 'barang';
    protected $primaryKey = 'id_barang';
    protected $allowedFields = ['nama_barang', 'id_kategori', 'harga_beli', 'harga_jual', 'jumlah_stok', 'keterangan_barang'];
    protected $useTimestamps = true;

    // for reduce stock
    public function reduceStock($id_barang, $jumlah)
    {
        $barang = $this->find($id_barang);
        $stokBaru = $barang['jumlah_stok'] - $jumlah;

        if ($stokBaru < 0) {
            $stokBaru = 0;
        }
        $this->update($id_barang, ['jumlah_stok' => $stokBaru]);
    }
}
