<?php

namespace App\Models;

use CodeIgniter\Model;

class StockModel extends Model
{
    protected $table = 'barang';
    protected $primaryKey = 'id_barang';
    protected $allowedFields = ['nama_barang', 'id_kategori', 'harga_beli', 'harga_jual', 'jumlah_stok', 'keterangan_barang'];
    protected $useTimestamps = true;

    public function reduceStock($id_barang, $jml_terjual)
    {
        $barang = $this->find($id_barang);
        if ($barang) {
            $stokBaru = $barang['jumlah_stok'] - $jml_terjual;

            if ($stokBaru < 0) {
                $stokBaru = 0;
            }
            $this->update($id_barang, ['jumlah_stok' => $stokBaru]);
        }
    }
    public function getTotalStock()
    {
        return $this->countAllResults();
    }
}
class CategoriesModel extends Model
{
    protected $table = 'kategori_barang';
    protected $primaryKey = 'id_kategori';
    protected $allowedFields = ['id_ktgri', 'nama_kategori', 'spesifikasi'];

    protected $useTimestamps = true;
}
