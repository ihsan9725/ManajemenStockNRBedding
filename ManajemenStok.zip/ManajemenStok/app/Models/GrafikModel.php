<?php

namespace App\Models;

use CodeIgniter\Model;

class GrafikModel extends Model
{
    protected $table = 'penjualan';
    public function getNumbercategory()
    {
        return $this->select('kategori. nama_kategori, COUNT(nama_barang.id_barang) as jumlah_barang')
            ->join('kategori', 'barang.id_kategori = kategori. id_kategori', 'left')
            ->groupBy('barang.id_kategori')
            ->findAll();
    }
}
