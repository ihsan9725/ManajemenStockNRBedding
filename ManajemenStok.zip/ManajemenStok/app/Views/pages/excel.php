<?php
header("Content-type: application/vnd-ms-excel");
header("Content-Disposition: attachment; filename=Data Penjualan.xls");
?>

<html>

<body>
    <table border="1">
        <thead>
            <tr>
                <th>No Transaksi</th>
                <th>Nama Pelanggan</th>
                <th>Nama Barang</th>
                <th>Harga Satuan Toko</th>
                <th>Harga Beli Pelanggan</th>
                <th>Jumlah Terjual</th>
                <th>Total Harga</th>
                <th>Total Biaya Beli (Dari supplier)</th>
                <th>Keuntungan</th>
                <th>Metode Pembayaran</th>
                <th>Keterangan</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($penjualan as $jual) : ?>
                <tr>
                    <td><?= $jual['no_transaksi'] ?></td>
                    <td><?= $jual['nama_pelanggan'] ?></td>
                    <td><?= $jual['nama_barang'] ?></td>
                    <td><?= formatRupiah($jual['harga_satuan_toko']) ?></td>
                    <td><?= formatRupiah($jual['harga_beli']) ?></td>
                    <td><?= $jual['jml_terjual'] ?></td>
                    <td><?= formatRupiah($jual['total_harga']) ?></td>
                    <td><?= formatRupiah($jual['total_biaya_beli']) ?></td>
                    <td><?= formatRupiah($jual['keuntungan']) ?></td>
                    <td><?= $jual['metode_pembayaran'] ?></td>
                    <td><?= $jual['keterangan'] ?></td>
                <?php endforeach; ?>
        </tbody>
    </table>

</body>

</html>