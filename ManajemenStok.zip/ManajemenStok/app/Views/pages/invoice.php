<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Invoice</title>
    <style>
        /* Mengatur ukuran halaman untuk A4 */
        @page {
            size: A4;
            margin: 20mm;
        }

        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 20mm;
            box-sizing: border-box;
        }

        .invoice-header,
        .invoice-footer {
            text-align: center;
            margin-bottom: 20px;
        }

        .invoice-header h1 {
            font-size: 24px;
            margin: 0;
        }

        .invoice-header p {
            margin: 5px 0;
        }

        .invoice-details {
            display: flex;
            justify-content: space-between;
            margin-bottom: 20px;
        }

        .invoice-details div {
            width: 48%;
        }

        .invoice-table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }

        .invoice-table th,
        .invoice-table td {
            border: 1px solid #000;
            padding: 8px;
            text-align: left;
        }

        .total-section {
            text-align: right;
            margin-bottom: 20px;
        }

        .total-section p {
            margin: 5px 0;
        }
    </style>
</head>

<body>
    <div class="invoice-header">
        <h1>INVOICE</h1>
        <p><strong>NR Bedding.</strong><br>Alat-alat Tidur Terlengkap</p>
    </div>

    <div class="invoice-details">
        <div>
            <p><strong>Kepada:</strong><br> <?= $jual['nama_pelanggan'] ?><br></p>
        </div>
        <div>
            <p><strong>Id: <?= $jual['id'] ?></strong><br>
                <strong>Tanggal:</strong> <?= $jual['created_at'] ?><br>
                <strong>No Invoice:</strong> <?= $jual['no_transaksi'] ?>
            </p>
        </div>
    </div>

    <table class="invoice-table">
        <thead>
            <tr>
                <th>Keterangan</th>
                <th>Harga</th>
                <th>Jml</th>
                <th>Total</th>
            </tr>
        </thead>
        <tbody>
            <tr>
                <td><?= $jual['keterangan'] ?></td>
                <td><?= $jual['nama_pelanggan'] ?></td>
                <td><?= $jual['jml_terjual'] ?></td>
                <td><?= $jual['total_biaya_beli'] ?></td>
            </tr>

        </tbody>
    </table>

    <div class="total-section">
        <p><strong>Sub Total:</strong> Rp <?= $jual['total_biaya_beli'] ?></p>
        <p><strong>Pajak:</strong> Rp -</p>
        <p><strong>Total:</strong> Rp <?= $jual['total_biaya_beli'] ?></p>
    </div>

    <div class="invoice-footer">
        <p><strong>Pembayaran:</strong><br>Nama: NR Bedding.<br>No Rek: +123-456-7890</p>
        <p>Terima kasih atas pembelian Anda</p>
        <p><strong><?= $jual['nama_pelanggan'] ?></strong></p>
    </div>
</body>

</html>

</html>