<?php

if (!function_exists('formatRupiah')) {
    function formatRupiah($angka)
    {
        log_message('debug', 'Currency_Helper dipanggil');
        return 'Rp ' . number_format($angka, 0, ',', '.');
    }
}
