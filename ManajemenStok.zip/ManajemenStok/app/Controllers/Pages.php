<?php

namespace App\Controllers;

use App\Models\CategoriesModel;
use App\Models\PagesModel;
use App\Models\StockModel;
use App\Models\SellerModel;
use App\Models\GrafikModel;

class Pages extends BaseController
{
    protected $StockModel;
    protected $CategoriesModel;
    protected $SellerModel;
    protected $GrafikModel;
    public function __construct()
    {
        $this->StockModel = new stockModel();
        $this->CategoriesModel = new CategoriesModel();
        $this->SellerModel = new SellerModel();
    }
    public function index()
    {
        // $SellerModel = new SellerModel();
        // $countData = $SellerModel->countAll();
        // $db = \Config\Database::connect();
        // $builder = $db->table('penjualan');
        // $countData = $builder->countAll();
        return view('pages/login');
    }

    public function home()
    {
        $StockModel = new StockModel();
        $data['totalStock'] = $StockModel->getTotalStock();

        $SellerModel = new SellerModel();
        $data['totalSales'] = $SellerModel->getTotalSales();

        return view('pages/home', $data);
    }



    public function profile()
    {
        return view('pages/profile');
    }

    public function stock()
    {
        //call model
        $stockModel = new StockModel();
        $CategoriesModel = new CategoriesModel();
        // take all data from tb barang
        helper('currency_helper');
        $data['barang'] = $stockModel->findAll();
        //take all data from kategori barang
        $data['kategori_barang'] = $CategoriesModel->findAll();
        return view('pages/stock', $data);
    }

    public function save()
    {
        $nama_barang = $this->request->getPost('nama_barang');
        //for chech categorie name there is in database
        $existingstock = $this->StockModel->where('nama_barang', $nama_barang)->first();

        if ($existingstock) {
            session()->setFlashdata('duplicate', 'Nama Barang Sudah Ada!.');
            return redirect()->back()->with('error', 'Nama Kategori Sudah ada');
        }
        $this->StockModel->save([
            'nama_barang' => $this->request->getVar('nama_barang'),
            'id_ktgri' => $this->request->getVar('id_ktgri'),
            'harga_beli' => $this->request->getVar('harga_beli'),
            'harga_jual' => $this->request->getVar('harga_jual'),
            'id_kategori' => $this->request->getVar('id_kategori'),
            'jumlah_stok' => $this->request->getVar('jumlah_stok'),
            'keterangan_barang' => $this->request->getVar('keterangan_barang')
        ]);
        session()->setFlashdata('success', 'Data berhasil disimpan.');
        return redirect()->to('pages/stock');
    }
    public function edit($id_barang)
    {
        $data['item'] = $this->StockModel->find($id_barang);
        return view('pages/stock', $data);
    }
    public function update($id_barang)
    {
        $this->StockModel->update($id_barang, [
            'nama_barang' => $this->request->getPost('nama_barang'),
            'id_ktgri' => $this->request->getPost('id_ktgri'),
            'harga_beli' => $this->request->getPost('harga_beli'),
            'harga_jual' => $this->request->getPost('harga_jual'),
            'id_kategori' => $this->request->getPost('id_kategori'),
            'jumlah_stok' => $this->request->getPost('jumlah_stok'),
            'keterangan_barang' => $this->request->getPost('keterangan_barang')

        ]);
        session()->setFlashdata('update', 'Data berhasil diupdate.');
        return redirect()->to('/pages/stock')->with('message', 'Data berhasil diupdate!');
    }
    public function beforedelete($id_barang)
    {
        $data['barang'] = $this->StockModel->find($id_barang);
        return view('pages/stock', $data);
    }
    public function delete($id_barang)
    {
        $this->StockModel->delete($id_barang);
        session()->setFlashdata('delete', 'Data berhasil dihapus.');
        return redirect()->to('/pages/stock')->with('message', 'Data berhasil di hapus!');
    }

    public function categories()
    {
        //call model
        $CategoriesModel = new CategoriesModel();
        // take all data from tb barang
        $data['kategori_barang'] = $CategoriesModel->findAll();

        return view('pages/stock', $data);
    }
    public function getStockData($id_barang)
    {
        log_message('debug', "fecthing data for barang ID: $id_barang");

        $StockModel = new StockModel();
        $nama_barang = $StockModel->find($id_barang);

        if ($nama_barang) {
            return $this->response->setJSON($nama_barang);
        } else {
            return $this->response->setJSON(['error' => 'data not found'], 404);
        }
    }
}
