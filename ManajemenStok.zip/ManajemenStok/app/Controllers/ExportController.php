<?php

namespace App\Controllers;

use App\Models\CategoriesModel;
use App\Models\PagesModel;
use App\Models\StockModel;
use App\Models\SellerModel;
use App\Models\GrafikModel;

use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;

class ExportController extends BaseController
{
    protected $StockModel;
    protected $CategoriesModel;
    protected $SellerModel;
    protected $GrafikModel;

    public function exportCSV()
    {
        $SellerModel = new SellerModel();

        $penjualan = $SellerModel->findAll();

        $filename = 'Data Penjualan' . date('Ymd') . '.csv';

        // Set header untuk download file CSV
        header("Content-Description: File Transfer");
        header("Content-Disposition: attachment; filename=$filename");
        header("Content-Type: application/csv; ");

        // Buka output stream
        $file = fopen('php://output', 'w');

        // Tulis header kolom ke file CSV
        $header = ['ID', 'No Transaksi', 'Nama Pelanggan', 'Id Barang', 'Nama Barang', 'Jumlah Terjual', 'Total Harga', 'Harga Beli', 'Harga Satuan Toko', 'Total Biaya Beli', 'Keuntungan', 'Metode Pembayaran', 'Keterangan', 'Dibuat Pada Tanggal', 'Di Edit Pada Tanggal'];
        fputcsv($file, $header);

        // Tulis data ke file CSV
        foreach ($penjualan as $jual) {
            $data = [
                $jual['id'],
                $jual['no_transaksi'],
                $jual['nama_pelanggan'],
                $jual['id_barang'],
                $jual['nama_barang'],
                $jual['jml_terjual'],
                $jual['total_harga'],
                $jual['harga_beli'],
                $jual['harga_satuan'],
                $jual['total_biaya'],
                $jual['keuntungan'],
                $jual['metode_pembayaran'],
                $jual['keterangan'],
                $jual['created_at'],
                $jual['updated_at'],

            ];
            fputcsv($file, $data);
        }

        // Tutup output stream
        fclose($file);

        // Stop eksekusi script
        exit();
    }

    public function exportToExcel()
    {
        // Ambil data dari database
        $db = \Config\Database::connect();
        $query = $db->query("SELECT id, no_transaksi,nama_pelanggan,id_barang,nama_barang,jml_terjual,total_harga,harga_beli, harga_satuan_toko,total_biaya_beli,keuntungan,metode_pembayaran,keterangan, created_at,updated_at FROM penjualan");
        $data = $query->getResultArray();

        // Tambahkan header kolom
        $header = ['ID', 'No Transaksi', 'Nama Pelanggan', 'Id Barang', 'Nama Barang', 'Jumlah Terjual', 'Total Harga', 'Harga Beli', 'Harga Satuan Toko', 'Total Biaya Beli', 'Keuntungan', 'Metode Pembayaran', 'Keterangan', 'Dibuat Pada Tanggal', 'Di Edit Pada Tanggal'];
        array_unshift($data, $header);

        // Ekspor ke Excel (gunakan kode sebelumnya untuk menulis data)
        // ...
        $fileName = 'Data Penjualan.xlsx';
        $writer = new Xlsx($spreadsheet);

        // Header untuk mendownload file
        header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
        header('Content-Disposition: attachment;filename="' . $fileName . '"');
        header('Cache-Control: max-age=0');

        // Output file ke browser
        $writer->save('php://output');
        exit;
    }
}
