<?php

namespace App\Controllers;

use App\Models\SellerModel;
use App\Models\StockModel;
use Dompdf\Helpers;
use Dompdf\Dompdf;

// helper('CurrencyHelper');

class SellerController extends BaseController
{
    protected $SellerModel;
    protected $StockModel;

    public function __construct()
    {
        $this->SellerModel = new SellerModel();
        $this->StockModel = new StockModel();
    }
    public function index()
    {
        return view('/page/seller');
    }
    public function seller()
    {
        helper('currency_helper');
        $data = ['total_harga' => formatRupiah(10000),];

        $data['penjualan'] = $this->SellerModel->findAll();
        $data['barang'] = $this->StockModel->findAll();

        return view('/pages/seller', $data);
    }
    public function save()
    {
        helper('currency_helper');

        $no_transaksi = $this->request->getPost('no_transaksi');
        //for chech categorie name there is in database
        $existingNotransaction = $this->SellerModel->where('no_transaksi', $no_transaksi)->first();

        if ($existingNotransaction) {
            session()->setFlashdata('duplicate', 'No Transaksi Sudah Ada!.');
            return redirect()->back()->with('error', 'Nama Kategori Sudah ada');
        }

        // Ambil data dari form untuk panggil helper dan angka jadi rupiah
        $id = $this->request->getVar('id');
        $jml_terjual = $this->request->getVar('jml_terjual');
        $total_harga = str_replace(['Rp', '.', ','], '', $this->request->getVar('total_harga')); // Konversi ke angka murni
        $harga_beli = str_replace(['Rp', '.', ','], '', $this->request->getVar('harga_beli')); // Konversi ke angka murni
        $harga_satuan_toko = str_replace(['Rp', '.', ','], '', $this->request->getVar('harga_satuan_toko')); // Konversi ke angka murni
        $total_biaya_beli = str_replace(['Rp', '.', ','], '', $this->request->getVar('total_biaya_beli')); // Konversi ke angka murni
        $keuntungan = str_replace(['Rp', '.', ','], '', $this->request->getVar('keuntungan')); // Konversi ke angka murni



        $id_barang = $this->request->getVar('id_barang'); // Ambil ID barang dari form
        $jml_terjual = $this->request->getVar('jml_terjual'); // Ambil jumlah terjual dari form

        // Ambil data barang dari database
        $barang = $this->StockModel->find($id_barang);

        // Validasi stok barang
        if (!$barang || $barang['jumlah_stok'] <= 0) {
            session()->setFlashdata('outofstock1', 'Stok barang habis, tidak dapat melakukan penjualan.');
            return redirect()->back();
        }

        if ($barang['jumlah_stok'] < $jml_terjual) {
            session()->setFlashdata('outofstock2', 'Jumlah terjual melebihi stok yang tersedia.');
            return redirect()->back();
        }

        $this->SellerModel->save([
            'id' => $this->request->getVar('id'),
            'no_transaksi' => $this->request->getVar('no_transaksi'),
            'nama_pelanggan' => $this->request->getVar('nama_pelanggan'),
            'id_barang' => $this->request->getVar('id_barang'),
            'nama_barang' => $this->request->getVar('nama_barang'),
            'jml_terjual' => $this->request->getVar('jml_terjual'),
            'total_harga' => $this->request->getVar('total_harga'),
            'harga_beli' => $this->request->getVar('harga_beli'),
            'harga_satuan_toko' => $this->request->getVar('harga_satuan_toko'),
            'total_biaya_beli' => $this->request->getVar('total_biaya_beli'),
            'keuntungan' => $this->request->getVar('keuntungan'),
            'metode_pembayaran' => $this->request->getVar('metode_pembayaran'),
            'keterangan' => $this->request->getVar('keterangan')



        ]);
        $this->StockModel->reduceStock($id_barang, $jml_terjual);

        session()->setFlashdata('success', 'Data berhasil disimpan.');
        return redirect()->to('seller/seller');
    }
    public function edit($id)
    {
        $data['kategori'] = $this->SellerModel->find($id);
        return view('seller/seller', $data);
    }

    public function update($id)
    {
        $this->SellerModel->update($id, [
            'no_transaksi' => $this->request->getPost('no_transaksi'),
            'nama_pelanggan' => $this->request->getPost('nama_pelanggan'),
            'nama_barang' => $this->request->getPost('nama_barang'),
            'jml_terjual' => $this->request->getPost('jml_terjual'),
            'total_harga' => $this->request->getPost('total_harga'),
            'harga_beli' => $this->request->getPost('harga_beli'),
            'harga_satuan_toko' => $this->request->getPost('harga_satuan_toko'),
            'total_biaya_beli' => $this->request->getPost('total_biaya_beli'),
            'keuntungan' => $this->request->getPost('keuntungan'),
            'metode_pembayaran' => $this->request->getPost('metode_pembayaran'),
            'keterangan' => $this->request->getPost('keterangan')
        ]);
        session()->setFlashdata('update', 'Data berhasil diupdate.');
        return redirect()->to('/seller/seller')->with('message', 'Data berhasil diupdate!');
    }
    public function delete($id)
    {
        $this->SellerModel->delete($id);
        session()->setFlashdata('delete', 'Data berhasil dihapus!.');

        return redirect()->to('seller/seller')->with('message', 'Data berhasil di hapus!');
    }
    public function getStockData($id_barang)
    {
        log_message('debug', "fecthing data for barang ID: $id_barang");

        $StockModel = new StockModel();
        $barang = $StockModel->find($id_barang);
        $harga_satuan = $StockModel->find($id_barang);

        if ($barang) {
            return $this->response->setJSON($barang);
        } else {
            return $this->response->setJSON(['error' => 'data not found'], 404);
        }

        // return $this->response->setJSON($nama_barang);
    }
    public function excel()
    {
        $data = [
            'penjualan' => $this->SellerModel->findAll()
        ];

        echo view('/pages/excel', $data);
    }
    public function exportCSV()
    {
        $SellerModel = new SellerModel();

        $penjualan = $SellerModel->findAll();

        $filename = 'Data Penjualan' . date('Ymd') . '.csv';

        // Set header untuk download file CSV
        header("Content-Description: File Transfer");
        header("Content-Disposition: attachment; filename=$filename");
        header("Content-Type: application/csv; ");

        // Buka output stream
        $file = fopen('php://output', 'w');

        // Tulis header kolom ke file CSV
        $header = ['ID', 'No Transaksi', 'Nama Pelanggan', 'Id Barang', 'Nama Barang', 'Jumlah Terjual', 'Total Harga', 'Harga Beli', 'Harga Satuan Toko', 'Total Biaya Beli', 'Keuntungan', 'Metode Pembayaran', 'Keterangan', 'Dibuat Pada Tanggal', 'Di Edit Pada Tanggal'];
        fputcsv($file, $header);

        // Tulis data ke file CSV
        foreach ($penjualan as $jual) {
            $data = [
                $jual['id'],
                $jual['no_transaksi'],
                $jual['nama_pelanggan'],
                $jual['id_barang'],
                $jual['nama_barang'],
                $jual['jml_terjual'],
                $jual['total_harga'],
                $jual['harga_beli'],
                $jual['harga_satuan'],
                $jual['total_biaya'],
                $jual['keuntungan'],
                $jual['metode_pembayaran'],
                $jual['keterangan'],
                $jual['created_at'],
                $jual['updated_at'],

            ];
            fputcsv($file, $data);
        }

        // Tutup output stream
        fclose($file);

        // Stop eksekusi script
        exit();
    }
    public function generatePDF($id)
    {
        $jual = $this->SellerModel->find($id);

        if (!$jual) {
            throw new \CodeIgniter\Exceptions\PageNotFoundException("Invoice dengan ID $id tidak ditemukan.");
        }

        // Load view to render PDF
        $html = view('pages/invoice', ['jual' => $jual]);

        // Generate PDF
        $dompdf = new Dompdf();
        $dompdf->loadHtml($html);
        $dompdf->setPaper('A4', 'portrait');
        $dompdf->render();

        // Output PDF
        $dompdf->stream("invoice_$id.pdf", ["Attachment" => true]);
    }
}
