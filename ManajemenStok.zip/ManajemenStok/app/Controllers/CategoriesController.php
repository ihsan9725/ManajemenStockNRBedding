<?php

namespace App\Controllers;

use App\Models\CategoriesModel;
use App\Models\StockModel;

class CategoriesController extends BaseController
{


    protected $StockModel;
    protected $CategoriesModel;
    public function __construct()
    {
        $this->StockModel = new StockModel();
        $this->CategoriesModel = new CategoriesModel();
    }
    public function index()
    {

        return view('categories/categories');
    }
    public function categories()
    {

        $data['kategori_barang'] = $this->CategoriesModel->findAll();

        return view('pages/categories', $data);
        return view('pages/stock', $data);
    }
    public function save()
    {
        $nama_kategori = $this->request->getPost('nama_kategori');
        //for chech categorie name there is in database
        $existingcategories = $this->CategoriesModel->where('nama_kategori', $nama_kategori)->first();

        if ($existingcategories) {
            session()->setFlashdata('duplicate', 'Nama Kategori Sudah Ada!.');
            return redirect()->back()->with('error', 'Nama Kategori Sudah ada');
        }

        $this->CategoriesModel->save([
            'id_ktgri' => $this->request->getVar('id_ktgri'),
            'nama_kategori' => $this->request->getVar('nama_kategori'),
            'spesifikasi' => $this->request->getVar('spesifikasi')
        ]);
        session()->setFlashdata('success', 'Data berhasil disimpan.');
        return redirect()->to('categories/categories');
    }

    public function edit($id_kategori)
    {
        $data['kategori'] = $this->CategoriesModel->find($id_kategori);
        return view('pages/categories', $data);
    }

    public function update($id_kategori)
    {

        $this->CategoriesModel->update($id_kategori, [
            'id_ktgri' => $this->request->getPost('id_ktgri'),
            'nama_kategori' => $this->request->getPost('nama_kategori'),
            'spesifikasi' => $this->request->getPost('spesifikasi')
        ]);
        session()->setFlashdata('update', 'Data berhasil diupdate.');
        return redirect()->to('/categories/categories')->with('message', 'Data berhasil diupdate!');
    }

    public function beforedelete($id_kategori)
    {
        $data['kategori'] = $this->CategoriesModel->find($id_kategori);
        return view('pages/categories', $data);
    }
    public function delete($id_kategori)
    {
        $this->CategoriesModel->delete($id_kategori);
        session()->setFlashdata('delete', 'Data berhasil dihapus!.');

        return redirect()->to('categories/categories')->with('message', 'Data berhasil di hapus!');
    }
}
