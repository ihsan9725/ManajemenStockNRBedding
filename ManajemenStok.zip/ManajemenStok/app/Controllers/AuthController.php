<?php

namespace App\Controllers;

use App\Models\UserModel;

class AuthController extends BaseController
{
    protected $userModel;

    public function __construct()
    {
        $this->userModel = new UserModel();
    }

    public function register()
    {
        return view('pages/register');
    }

    public function registerProcess()
    {
        $validation = $this->validate([
            'username' => 'required|min_length[3]|is_unique[users.username]',
            'email'    => 'required|valid_email|is_unique[users.email]',
            'password' => 'required|min_length[6]',
        ]);

        if (!$validation) {
            return redirect()->back()->withInput()->with('errors', $this->validator->getErrors());
        }

        $this->userModel->save([
            'username' => $this->request->getPost('username'),
            'email'    => $this->request->getPost('email'),
            'password' => password_hash($this->request->getPost('password'), PASSWORD_BCRYPT),
        ]);
        session()->setFlashdata('registsuccess', 'Data berhasil disimpan.');
        return redirect()->to('auth/login')->with('success', 'Registration successful! Please login.');
    }
    public function index()
    {
        return view('pages/login');
    }

    public function login()
    {
        return view('pages/login');
    }

    public function loginProcess()
    {
        $user = $this->userModel->where('email', $this->request->getPost('email'))->first();

        if ($user && password_verify($this->request->getPost('password'), $user['password'])) {
            session()->set('user', $user);

            session()->setFlashdata('loginsuccess', 'Data berhasil disimpan.');
            return redirect()->to('pages/home');
        }
        session()->setFlashdata('loginerror', 'Data berhasil disimpan.');
        return redirect()->back()->with('error', 'Invalid email or password.');
    }

    public function logout()
    {
        session()->destroy();
        return redirect()->to('auth/login');
    }
}
