<?php

namespace App\Controllers;

use App\Models\SupplierModel;

class SupplierController extends BaseController
{
    protected $SupplierModel;

    public function __construct()
    {
        $this->SupplierModel = new SupplierModel();
    }
    public function index()
    {
        return view('/page/supplier');
    }
    public function supplier()
    {
        $data['supplier'] = $this->SupplierModel->findAll();

        return view('/pages/supplier', $data);
    }
    public function save()
    {
        $nama_supplier = $this->request->getPost('nama_supplier');
        //for chech categorie name there is in database
        $existingsupplier = $this->SupplierModel->where('nama_supplier', $nama_supplier)->first();

        if ($existingsupplier) {
            session()->setFlashdata('duplicate', 'Nama Barang Sudah Ada!.');
            return redirect()->back()->with('error', 'Nama Kategori Sudah ada');
        }
        $this->SupplierModel->save([
            'nama_supplier' => $this->request->getVar('nama_supplier'),
            'kontak_supplier' => $this->request->getVar('kontak_supplier'),
            'alamat_supplier' => $this->request->getVar('alamat_supplier')
        ]);
        session()->setFlashdata('success', 'Data berhasil disimpan.');
        return redirect()->to('supplier/supplier');
    }
    public function edit($id_supplier)
    {
        $data['supplie'] = $this->SupplierModel->find($id_supplier);
        return view('pages/supplier', $data);
    }
    public function update($id_supplier)
    {
        $this->SupplierModel->update($id_supplier, [
            'nama_supplier' => $this->request->getPost('nama_supplier'),
            'kontak_supplier' => $this->request->getPost('kontak_supplier'),
            'alamat_supplier' => $this->request->getPost('alamat_supplier')

        ]);
        session()->setFlashdata('update', 'Data berhasil diupdate.');
        return redirect()->to('/supplier/supplier')->with('message', 'Data berhasil diupdate!');
    }
    public function delete($id_supplier)
    {
        $this->SupplierModel->delete($id_supplier);
        session()->setFlashdata('delete', 'Data berhasil dihapus.');
        return redirect()->to('/supplier/supplier')->with('message', 'Data berhasil di hapus!');
    }
}
// kalau menggunganan '/' berarti mengarah ke route dan controller supplier jika view arahkan dulu ke folder pages